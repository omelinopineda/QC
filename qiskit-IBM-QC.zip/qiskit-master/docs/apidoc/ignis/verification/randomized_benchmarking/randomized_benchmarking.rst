.. _qiskit-ignis-verification-randomized_benchmarking:

**************************************************
qiskit.ignis.verification.randomized_benchmarking
**************************************************

.. currentmodule:: qiskit.ignis.verification.randomized_benchmarking


.. automodapi:: qiskit.ignis.verification.randomized_benchmarking
  :no-heading:
  :no-inheritance-diagram:
  :inherited-members:
