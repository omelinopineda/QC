.. _qiskit-ignis-verification-quantum_volume:

*****************************************
qiskit.ignis.verification.quantum_volume
*****************************************

.. currentmodule:: qiskit.ignis.verification.quantum_volume


.. automodapi:: qiskit.ignis.verification.quantum_volume
  :no-heading:
  :no-inheritance-diagram:
  :inherited-members:
