.. _qiskit-ignis:

****************
qiskit.ignis
****************

.. currentmodule:: qiskit.ignis


.. automodapi:: qiskit.ignis
  :no-heading:
  :no-inheritance-diagram:
  :inherited-members:

Submodules
==========

.. toctree::
   :maxdepth: 1

   characterization/characterization
   mitigation/mitigation
   verification/verification
