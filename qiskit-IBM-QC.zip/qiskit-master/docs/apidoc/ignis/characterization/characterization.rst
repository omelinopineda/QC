.. _qiskit-ignis-characterization:

******************************
qiskit.ignis.characterization
******************************

.. currentmodule:: qiskit.ignis.characterization


.. automodapi:: qiskit.ignis.characterization
  :no-heading:
  :no-inheritance-diagram:
  :inherited-members:

Submodules
==========

.. toctree::
   :maxdepth: 1

   coherence/coherence
   gates/gates
   hamiltonian/hamiltonian
