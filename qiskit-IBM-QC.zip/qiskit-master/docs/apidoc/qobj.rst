.. _qiskit-qobj:

***********
qiskit.qobj
***********

.. currentmodule:: qiskit.qobj


.. automodapi:: qiskit.qobj
  :no-heading:
  :no-inheritance-diagram:
  :inherited-members:
