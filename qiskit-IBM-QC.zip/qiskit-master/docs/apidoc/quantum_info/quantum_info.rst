.. _qiskit-quantum_info:

*******************
qiskit.quantum_info
*******************

.. currentmodule:: qiskit.quantum_info


.. automodapi:: qiskit.quantum_info
  :no-heading:
  :no-inheritance-diagram:

Submodules
==========

.. toctree::
   :maxdepth: 1

   synthesis/synthesis
