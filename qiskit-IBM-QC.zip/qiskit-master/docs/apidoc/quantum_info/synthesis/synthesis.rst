.. _qiskit-quantum_info-synthesis:

*****************************
qiskit.quantum_info.synthesis
*****************************

.. currentmodule:: qiskit.quantum_info.synthesis


.. automodapi:: qiskit.quantum_info.synthesis
  :no-heading:
  :no-inheritance-diagram:
  :inherited-members:
