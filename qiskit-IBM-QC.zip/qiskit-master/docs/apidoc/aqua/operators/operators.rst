.. _qiskit-aqua-operators:

***********************
qiskit.aqua.operators
***********************

.. currentmodule:: qiskit.aqua.operators


.. automodapi:: qiskit.aqua.operators
  :no-heading:
  :no-inheritance-diagram:
  :inherited-members:
