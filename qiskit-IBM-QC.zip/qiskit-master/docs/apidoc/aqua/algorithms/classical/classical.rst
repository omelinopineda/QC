.. _qiskit-aqua-algorithms-classical:

********************************
qiskit.aqua.algorithms.classical
********************************

.. currentmodule:: qiskit.aqua.algorithms.classical


.. automodapi:: qiskit.aqua.algorithms.classical
  :no-heading:
  :no-inheritance-diagram:
  :inherited-members:
