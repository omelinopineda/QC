.. _qiskit-aqua-algorithms-many_sample:

**********************************
qiskit.aqua.algorithms.many_sample
**********************************

.. currentmodule:: qiskit.aqua.algorithms.many_sample


.. automodapi:: qiskit.aqua.algorithms.many_sample
  :no-heading:
  :no-inheritance-diagram:
  :inherited-members:
