.. _qiskit-aqua-algorithms:

***********************
qiskit.aqua.algorithms
***********************

.. currentmodule:: qiskit.aqua.algorithms


.. automodapi:: qiskit.aqua.algorithms
  :no-heading:
  :no-inheritance-diagram:
  :inherited-members:

Submodules
==========

.. toctree::
   :maxdepth: 1

   adaptive/adaptive
   classical/classical
   many_sample/many_sample
   single_sample/single_sample
