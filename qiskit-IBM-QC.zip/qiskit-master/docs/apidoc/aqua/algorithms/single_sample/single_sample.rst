.. _qiskit-aqua-algorithms-single_sample:

************************************
qiskit.aqua.algorithms.single_sample
************************************

.. currentmodule:: qiskit.aqua.algorithms.single_sample


.. automodapi:: qiskit.aqua.algorithms.single_sample
  :no-heading:
  :no-inheritance-diagram:
  :inherited-members:
