.. _qiskit-aqua-algorithms-adaptive:

*******************************
qiskit.aqua.algorithms.adaptive
*******************************

.. currentmodule:: qiskit.aqua.algorithms.adaptive


.. automodapi:: qiskit.aqua.algorithms.adaptive
  :no-heading:
  :no-inheritance-diagram:
  :inherited-members:
