.. _qiskit-aqua-components-reciprocals:

*************************************
qiskit.aqua.components.reciprocals
*************************************

.. currentmodule:: qiskit.aqua.components.reciprocals


.. automodapi:: qiskit.aqua.components.reciprocals
  :no-heading:
  :no-inheritance-diagram:
  :inherited-members:
