.. _qiskit-aqua-components-qfts:

*************************************
qiskit.aqua.components.qfts
*************************************

.. currentmodule:: qiskit.aqua.components.qfts


.. automodapi:: qiskit.aqua.components.qfts
  :no-heading:
  :no-inheritance-diagram:
  :inherited-members:
