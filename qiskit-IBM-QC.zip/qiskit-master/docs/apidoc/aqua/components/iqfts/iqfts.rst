.. _qiskit-aqua-components-iqfts:

*************************************
qiskit.aqua.components.iqfts
*************************************

.. currentmodule:: qiskit.aqua.components.iqfts


.. automodapi:: qiskit.aqua.components.iqfts
  :no-heading:
  :no-inheritance-diagram:
  :inherited-members:
