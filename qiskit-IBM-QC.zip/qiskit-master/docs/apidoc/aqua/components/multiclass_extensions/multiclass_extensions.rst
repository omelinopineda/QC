.. _qiskit-aqua-components-multiclass_extensions:

********************************************
qiskit.aqua.components.multiclass_extensions
********************************************

.. currentmodule:: qiskit.aqua.multiclass_extensions


.. automodapi:: qiskit.aqua.components.multiclass_extensions
  :no-heading:
  :no-inheritance-diagram:
  :inherited-members:
