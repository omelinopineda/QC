.. _qiskit-aqua-components-oracles:

*************************************
qiskit.aqua.components.oracles
*************************************

.. currentmodule:: qiskit.aqua.components.oracles


.. automodapi:: qiskit.aqua.components.oracles
  :no-heading:
  :no-inheritance-diagram:
  :inherited-members:
