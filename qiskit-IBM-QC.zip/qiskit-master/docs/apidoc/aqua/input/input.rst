.. _qiskit-aqua-input:

***********************
qiskit.aqua.input
***********************

.. currentmodule:: qiskit.aqua.input


.. automodapi:: qiskit.aqua.input
  :no-heading:
  :no-inheritance-diagram:
  :inherited-members:
