.. _qiskit-result:

*************
qiskit.result
*************

.. currentmodule:: qiskit.result


.. automodapi:: qiskit.result
  :no-heading:
  :no-inheritance-diagram:
  :inherited-members:
