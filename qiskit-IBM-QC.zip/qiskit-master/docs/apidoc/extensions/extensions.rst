.. _qiskit-extensions:

*****************
qiskit.extensions
*****************

.. currentmodule:: qiskit.extensions


.. automodapi:: qiskit.extensions
  :no-heading:
  :no-inheritance-diagram:

Submodules
==========

.. toctree::
   :maxdepth: 1

   simulator
   standard
