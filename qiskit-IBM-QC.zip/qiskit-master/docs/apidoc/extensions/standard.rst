.. _qiskit-extensions-standard:

**************************
qiskit.extensions.standard
**************************

.. currentmodule:: qiskit.extensions.standard


.. automodapi:: qiskit.extensions.standard
  :no-heading:
  :no-inheritance-diagram:
  :inherited-members:
