.. _qiskit-extensions-simulator:

***************************
qiskit.extensions.simulator
***************************

.. currentmodule:: qiskit.extensions.simulator


.. automodapi:: qiskit.extensions.simulator
  :no-heading:
  :no-inheritance-diagram:
  :inherited-members:
