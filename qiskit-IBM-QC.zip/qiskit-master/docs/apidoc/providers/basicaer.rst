.. _qiskit-providers-basicaer:

*************************
qiskit.providers.basicaer
*************************

.. currentmodule:: qiskit.providers.basicaer


.. automodapi:: qiskit.providers.basicaer
  :no-heading:
  :no-inheritance-diagram:
  :inherited-members:
