.. _qiskit-providers-aer-backends:

*****************************
qiskit.providers.aer.backends
*****************************

.. currentmodule:: qiskit.providers.aer.backends


.. automodapi:: qiskit.providers.aer.backends
  :no-heading:
  :no-inheritance-diagram:
  :inherited-members:
