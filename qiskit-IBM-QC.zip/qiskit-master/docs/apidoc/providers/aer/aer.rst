.. _qiskit-providers-aer:

*************************
qiskit.providers.aer
*************************

.. currentmodule:: qiskit.providers.aer


.. automodapi:: qiskit.providers.aer
  :no-heading:
  :no-inheritance-diagram:
  :inherited-members:

Submodules
==========

.. toctree::
   :maxdepth: 1

   aer_backends
   noise/noise
