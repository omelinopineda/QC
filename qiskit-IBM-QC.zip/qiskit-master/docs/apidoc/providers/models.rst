.. _qiskit-providers-models:

***********************
qiskit.providers.models
***********************

.. currentmodule:: qiskit.providers.models


.. automodapi:: qiskit.providers.models
  :no-heading:
  :no-inheritance-diagram:
  :inherited-members:
