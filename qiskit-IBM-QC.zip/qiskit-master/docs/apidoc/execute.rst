.. _qiskit-execute:

**************
qiskit.execute
**************

.. currentmodule:: qiskit.execute

.. autofunction:: execute
