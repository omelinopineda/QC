.. _qiskit-transpiler:

*****************
qiskit.transpiler
*****************

.. currentmodule:: qiskit.transpiler


.. automodapi:: qiskit.transpiler
  :no-heading:
  :no-inheritance-diagram:
  :inherited-members:

Submodules
==========

.. toctree::
   :maxdepth: 1

   passes/passes
   preset_passmanagers/preset_passmanagers
