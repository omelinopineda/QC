.. _qiskit-transpiler-mapping:

********************************
qiskit.transpiler.passes.mapping
********************************

.. currentmodule:: qiskit.transpiler.passes.mapping


.. automodapi:: qiskit.transpiler.passes.mapping
  :no-heading:
  :no-inheritance-diagram:
  :inherited-members:
