.. _qiskit-transpiler-passes:

************************
qiskit.transpiler.passes
************************

.. currentmodule:: qiskit.transpiler.passes


.. automodapi:: qiskit.transpiler.passes
  :no-heading:
  :no-inheritance-diagram:
  :inherited-members:

Submodules
==========

.. toctree::
   :maxdepth: 1

   mapping/mapping
