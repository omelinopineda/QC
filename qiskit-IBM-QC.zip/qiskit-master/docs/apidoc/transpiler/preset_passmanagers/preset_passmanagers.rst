.. _qiskit-transpiler-preset-passmanagers:

*************************************
qiskit.transpiler.preset_passmanagers
*************************************

.. currentmodule:: qiskit.transpiler.preset_passmanagers


.. automodapi:: qiskit.transpiler.preset_passmanagers
  :no-heading:
  :no-inheritance-diagram:
  :inherited-members:
